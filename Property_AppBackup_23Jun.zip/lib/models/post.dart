class Post {
  Post({
    this.postId,
    this.createdOn,
    this.updatedOn,
    this.postTitle,
    this.postDescription,
    this.propertyLocation,
    this.propertyPrice,
    this.propertySize,
    this.postPic,
    this.postedBy,
    this.propertyPriceType,
    this.propertySizeType,
    this.postStatus,
    this.propertyCity,
    this.userName,
    this.profilePic,
    this.postViewsCount,
  });

  Post.fromJson(dynamic json) {
    postId = json['post_id'];
    createdOn = json['created_on'];
    updatedOn = json['updated_on'];
    postTitle = json['post_title'];
    postDescription = json['post_description'];
    propertyLocation = json['property_location'];
    propertyPrice = json['property_price'];
    propertySize = json['property_size'];
    postPic = json['post_pic'];
    postedBy = json['posted_by'];
    propertyPriceType = json['property_price_type'];
    propertySizeType = json['property_size_type'];
    postStatus = json['post_status'];
    propertyCity = json['property_city'];
    userName = json['user_name'];
    profilePic = json['profile_pic'];
    postViewsCount = json['post_views_count'];
  }

  String? postId;
  String? createdOn;
  String? updatedOn;
  String? postTitle;
  String? postDescription;
  String? propertyLocation;
  String? propertyPrice;
  String? propertySize;
  String? postPic;
  String? postedBy;
  String? propertyPriceType;
  String? propertySizeType;
  String? postStatus;
  String? propertyCity;
  String? userName;
  String? profilePic;
  String? postViewsCount;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['post_id'] = postId;
    map['created_on'] = createdOn;
    map['updated_on'] = updatedOn;
    map['post_title'] = postTitle;
    map['post_description'] = postDescription;
    map['property_location'] = propertyLocation;
    map['property_price'] = propertyPrice;
    map['property_size'] = propertySize;
    map['post_pic'] = postPic;
    map['posted_by'] = postedBy;
    map['property_price_type'] = propertyPriceType;
    map['property_size_type'] = propertySizeType;
    map['post_status'] = postStatus;
    map['property_city'] = propertyCity;
    map['user_name'] = userName;
    map['profile_pic'] = profilePic;
    map['post_views_count'] = postViewsCount;
    return map;
  }
}
