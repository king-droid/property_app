import 'package:property_feeds/models/user.dart';

class UserProfile {
  UserProfile({this.postsCount, this.user});

  UserProfile.fromJson(dynamic json) {
    //json = jsonDecode(json);
    postsCount = "${json['posts_count']}";
    user = json['user'] != null ? User.fromJson(json['user']) : null;
  }

  String? postsCount;
  User? user;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['posts_count'] = postsCount;
    if (user != null) {
      map['user'] = user!.toJson();
    }
    return map;
  }
}
