import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:property_feeds/blocs/post/post_event.dart';
import 'package:property_feeds/blocs/post/post_state.dart';
import 'package:property_feeds/models/post_response.dart';
import 'package:property_feeds/models/user.dart';
import 'package:property_feeds/models/view_post_response.dart';
import 'package:property_feeds/networking/api_response.dart';
import 'package:property_feeds/services/post_service.dart';
import 'package:property_feeds/utils/app_utils.dart';

class PostBloc extends Bloc<PostEvent, PostState> {
  PostService postService = PostService();

  PostBloc() : super(Initial()) {
    on<AddPost>(addPost);
  }

  Future<void> addPost(AddPost event, Emitter<PostState> emit) async {
    emit(Loading());
    Map<String, dynamic> body;

    if ((event.pictures ?? []).isNotEmpty) {
      //List<MultipartFile> multipartFiles = [];

      body = {
        "method": "add_post",
        "user_id": event.userId ?? "",
        "requirement_type": (event.requirementType ?? "").trim(),
        "property_city": (event.city ?? "").trim(),
        "post_title": event.title ?? "",
        "post_description": event.description ?? "",
        "property_location": event.location ?? "",
        "property_price": event.prize ?? "",
        "property_size": event.size ?? "",
        "posted_by": event.userId ?? "",
        "property_price_type": event.prizeType ?? "",
        "property_size_type": event.sizeType ?? "",
      };

      /// Images files
      int i = 1;
      for (File? file in event.pictures ?? []) {
        //String fileName = file?.path.split('/').last ?? "";
        body["file$i"] = await MultipartFile.fromFile(file?.path ?? "",
            filename: file?.path ?? "".split('/').last);
        i = i + 1;
      }
    } else {
      body = {
        "method": "add_post",
        "user_id": event.userId ?? "",
        "requirement_type": (event.requirementType ?? "").trim(),
        "property_city": event.city ?? "",
        "post_title": event.title ?? "",
        "post_description": event.description ?? "",
        "property_location": event.location ?? "",
        "property_price": event.prize ?? "",
        "property_size": event.size ?? "",
        "posted_by": event.userId ?? "",
        "property_price_type": event.prizeType ?? "",
        "property_size_type": event.sizeType ?? "",
      };
    }

    print(body);

    FormData formData = new FormData.fromMap(body);

    final apiResponse = await postService.addPost(formData);
    if (apiResponse.status == Status.success) {
      PostResponse postResponse = PostResponse.fromJson(apiResponse.data);
      if (postResponse.status == "success") {
        if (postResponse.data != null) {
          emit(PostAdded(true, postResponse.data));
        } else {
          emit(PostAdded(false, postResponse.data));
          emit(Error("Post data not found"));
        }
      } else {
        emit(Error(postResponse.message));
      }
    } else {
      emit(Error(apiResponse.message ?? ""));
    }
  }

  Future<bool> viewPost(String postId) async {
    User? user = await AppUtils.getUser();
    String userId = user?.userId ?? "";
    Map<String, dynamic> body;
    body = {
      "method": "view_post",
      "user_id": userId,
      "post_id": postId,
    };

    final apiResponse = await postService.viewPost(body);
    if (apiResponse.status == Status.success) {
      ViewPostResponse viewPostResponse =
          ViewPostResponse.fromJson(apiResponse.data);
      if (viewPostResponse.status == "success") {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }
}
