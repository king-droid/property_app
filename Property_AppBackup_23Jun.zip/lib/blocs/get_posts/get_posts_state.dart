import 'package:property_feeds/models/post.dart';

abstract class GetPostsState {
  GetPostsState();
}

class Initial extends GetPostsState {
  Initial() : super();
}

class Loading extends GetPostsState {
  Loading() : super();
}

class PostsLoaded extends GetPostsState {
  final bool? result;
  final List<Post>? posts;

  PostsLoaded(this.result, this.posts) : super();
}

class Error extends GetPostsState {
  final String? error;

  Error(this.error) : super();
}
