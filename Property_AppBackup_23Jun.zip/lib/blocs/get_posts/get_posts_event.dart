abstract class GetPostsEvent {}

class GetPosts extends GetPostsEvent {
  final String? userId;
  final String? city;
  final String? category;
  final String? searchKeyword;

  GetPosts(this.userId, this.city, this.category, this.searchKeyword);
}
