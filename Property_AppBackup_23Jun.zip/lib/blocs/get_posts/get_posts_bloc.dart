import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:property_feeds/blocs/get_posts/get_posts_event.dart';
import 'package:property_feeds/blocs/get_posts/get_posts_state.dart';
import 'package:property_feeds/models/get_posts_response.dart';
import 'package:property_feeds/networking/api_response.dart';
import 'package:property_feeds/services/post_service.dart';

class GetPostsBloc extends Bloc<GetPostsEvent, GetPostsState> {
  PostService postService = PostService();

  GetPostsBloc() : super(Initial()) {
    on<GetPosts>(getAllPosts);
  }

  Future<void> getAllPosts(GetPosts event, Emitter<GetPostsState> emit) async {
    emit(Loading());
    Map<String, dynamic> params = {
      "method": "get_all_posts",
      "user_id": event.userId ?? "",
      "city": event.city?.trim(),
      "category": (event.category ?? "all").toLowerCase(),
      "search_keyword": (event.searchKeyword ?? "").trim().toLowerCase(),
    };

    print(params);
    final apiResponse = await postService.getAllPosts(params);
    if (apiResponse.status == Status.success && apiResponse.data != null) {
      GetPostsResponse getPostsResponse =
          GetPostsResponse.fromJson(apiResponse.data);
      if (getPostsResponse.status == "success") {
        if (getPostsResponse.data != null) {
          emit(PostsLoaded(true, getPostsResponse.data));
        } else {
          emit(PostsLoaded(false, getPostsResponse.data));
          emit(Error("Post data not found"));
        }
      } else {
        emit(Error(getPostsResponse.message));
      }
    } else {
      emit(Error(apiResponse.message ?? ""));
    }
  }
}
