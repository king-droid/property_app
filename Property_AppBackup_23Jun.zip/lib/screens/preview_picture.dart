import 'package:flutter/material.dart';
import 'package:property_feeds/constants/appColors.dart';
import 'package:property_feeds/constants/appConstants.dart';

class PreviewPictureScreen extends StatefulWidget {
  PreviewPictureScreen();

  @override
  _PreviewPictureScreenState createState() => _PreviewPictureScreenState();
}

class _PreviewPictureScreenState extends State<PreviewPictureScreen> {
  String? imagePath = "";
  late TransformationController controller;
  late TapDownDetails tabDownDetails;

  _PreviewPictureScreenState();

  @override
  void initState() {
    controller = TransformationController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    imagePath = ((ModalRoute.of(context)?.settings.arguments) as String) ?? "";
    return Scaffold(
      appBar: AppBar(
        leading: const BackButton(color: AppColors.white),
        backgroundColor: Colors.black87,
        elevation: 0,
        automaticallyImplyLeading: false,
      ),
      body: Container(
        color: Colors.black87,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
                //width: MediaQuery.of(context).size.width,
                //height: MediaQuery.of(context).size.height,
                child: (imagePath ?? "").isNotEmpty
                    ? GestureDetector(
                        onDoubleTapDown: (details) {
                          tabDownDetails = details;
                        },
                        onDoubleTap: () {
                          final positions = tabDownDetails.localPosition;
                          const double scale = 5;
                          final x = (positions.dx)! * (scale - 1);
                          final y = (positions.dy)! * (scale - 1);
                          final zooomed = Matrix4.identity()
                            ..translate(x, y)
                            ..scale(scale);
                          final value = controller.value.isIdentity()
                              ? zooomed
                              : Matrix4.identity();
                          controller.value = value;
                        },
                        child: InteractiveViewer(
                          clipBehavior: Clip.none,
                          transformationController: controller,
                          maxScale: 10,
                          panEnabled: true,
                          child: Image.network(
                            AppConstants.imagesBaseUrl +
                                "/post_images/" +
                                (imagePath ?? ""),
                          ),
                        ))
                    /*ExtendedImage.network(
                  AppConstants.imagesBaseUrl +
                      "/post_images/" +
                      (imagePath ?? ""),
                  fit: BoxFit.fitWidth,
                  mode: ExtendedImageMode.gesture,
                  initGestureConfigHandler: (state) {
                    return GestureConfig(
                      minScale: 1,
                      animationMinScale: 0.7,
                      maxScale: 3.0,
                      animationMaxScale: 3.5,
                      speed: 1.0,
                      inertialSpeed: 100.0,
                      initialScale: 1.0,
                      inPageView: false,
                      initialAlignment: InitialAlignment.center,
                    );
                  },
                )*/
                    : Container()),
          ],
        ),
      ),
    );
  }
}
