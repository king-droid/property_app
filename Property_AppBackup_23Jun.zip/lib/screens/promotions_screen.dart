import 'package:property_feeds/constants/appColors.dart';
import 'package:property_feeds/screens/promotion_item.dart';
import 'package:flutter/material.dart';

class Promotions extends StatefulWidget {
  @override
  _PromotionsState createState() => _PromotionsState();
}

class _PromotionsState extends State<Promotions> {
  List promotions = [
    {
      "title": "M3M Low Rise Floors Gurgaon - M3M 79",
      "dateTime": "April 12, 2023 03:18 PM",
      "company": "Gurgaon Real Estate",
      "postedBy": "",
      "description":
          "M3M Sector 79 is a residential project located in Gurugram (Gurgaon), India. It is a part of the larger M3M Group, which is a well-known real estate developer in India. If you're looking for a quality residential property in Gurugram, you can consider M3M Sector 79. \n\nRead More....",
      "link":
          "https://m3mprojects-gurgaon.in/sector-79/?utm_term=low%20rise%20apartments%20in%20gurgaon&utm_campaign=M3M+Projects&utm_source=adwords&utm_medium=ppc&hsa_acc=8403565174&hsa_cam=19660353966&hsa_grp=141203747730&hsa_ad=647693862228&hsa_src=g&hsa_tgt=kwd-304731123296&hsa_kw=low%20rise%20apartments%20in%20gurgaon&hsa_mt=p&hsa_net=adwords&hsa_ver=3&gclid=Cj0KCQjwxYOiBhC9ARIsANiEIfYVg4zfh9KTHHcN_fPpFxOp2kX6mbB6cGoZv-yW_rZrzEzKGtP6y8saAqt9EALw_wcB",
      "picture": "assets/promotions/promotion1.png"
    },
    {
      "title": "New launch plots in gurgaon - Starting Rs. 1.20 Lakh / Sq.yd",
      "dateTime": "Feb 20, 2023 08:00 AM",
      "company": "",
      "postedBy": "Rohit Kumar",
      "description":
          "A perfect opportunity to plot your way to happiness you can build the house of your dreams. Invest in Bonheur Avenue is a unique concept designed to offer you the best of both worlds. \n\nRead More....",
      "link": "",
      "picture": "assets/promotions/promotion2.png"
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        title: Text("Ads & Promotions",
            style: TextStyle(color: AppColors.screenTitleColor, fontSize: 16)),
        elevation: 1,
        centerTitle: true,
        actions: <Widget>[
          /*  IconButton(
            icon: Icon(
              Icons.search,
              color: AppColors.screenTitleColor,
            ),
            onPressed: () {},
          ),*/
        ],
      ),
      body: Container(
        child: ListView.builder(
          padding: EdgeInsets.symmetric(horizontal: 0),
          itemCount: promotions.length,
          itemBuilder: (BuildContext context, int index) {
            Map promotion = promotions[index];
            return PromotionItem(
              title: promotion["title"],
              dateTime: promotion["dateTime"],
              company: promotion["company"],
              postedBy: promotion["postedBy"],
              description: promotion["description"],
              link: promotion["link"],
              picture: promotion["picture"],
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(
          Icons.add,
        ),
        onPressed: () {},
      ),
    );
  }
}
