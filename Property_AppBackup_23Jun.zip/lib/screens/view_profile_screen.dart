import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:property_feeds/blocs/get_profile/get_profile_bloc.dart';
import 'package:property_feeds/blocs/get_profile/get_profile_event.dart';
import 'package:property_feeds/blocs/get_profile/get_profile_state.dart';
import 'package:property_feeds/constants/appColors.dart';
import 'package:property_feeds/constants/appConstants.dart';
import 'package:property_feeds/models/user.dart';

class ViewProfileScreen extends StatefulWidget {
  @override
  ViewProfileScreenState createState() => ViewProfileScreenState();
}

class ViewProfileScreenState extends State<ViewProfileScreen> {
  static Random random = Random();
  List<String> cities = [];
  bool status = false;
  User? user;
  String? userId;

  @override
  void initState() {
    SchedulerBinding.instance.addPostFrameCallback((_) {
      BlocProvider.of<GetProfileBloc>(context).add(GetProfile(userId ?? ""));
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    userId = ((ModalRoute.of(context)!.settings.arguments) as String) ?? "";
    return Scaffold(
      appBar: AppBar(
        leading: const BackButton(color: AppColors.screenTitleColor),
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        title: Text("Profile",
            style: TextStyle(color: AppColors.screenTitleColor, fontSize: 16)),
        elevation: 1,
        centerTitle: true,
      ),
      body: Container(
        color: Colors.white,
        child: setProfile(context),
      ),
    );
  }

  Widget setProfile(BuildContext context) {
    return BlocConsumer<GetProfileBloc, GetProfileState>(
      builder: (context, state) {
        if (state is Loading) {
          return Center(
            child: Container(
              color: AppColors.white,
              margin: const EdgeInsets.only(
                  left: 35.0, right: 35.0, top: 30.0, bottom: 10),
              width: 30,
              height: 30,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: AppColors.primaryColor,
              ),
            ),
          );
        } else if (state is ProfileLoaded) {
          user = state.userProfile?.user;
          cities = (user?.interestedCities ?? "").split(',');
          return SingleChildScrollView(
            child: Container(
              color: AppColors.white,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  profilePictureWidget(),
                  profileDetailsWidget(),
                  buildProfileDetailsSections(),
                  profileSectionsWidget(),
                ],
              ),
            ),
          );
        } else {
          return Container(
            child: Center(
              child: Text(
                "Failed to get user profile",
                style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                    fontSize: 13,
                    color: AppColors.lineBorderColor,
                    fontWeight: FontWeight.w600),
              ),
            ),
          );
        }
      },
      listener: (context, state) async {
        if (state is ProfileLoaded) {}
      },
    );
  }

  Widget profilePictureWidget() {
    return Container(
      margin: EdgeInsets.only(left: 10, top: 10),
      child: Container(
        child: GestureDetector(
          onTap: () {},
          child: (user?.profilePic ?? "").isNotEmpty
              ? Container(
                  child: CircleAvatar(
                    backgroundColor: AppColors.semiPrimary,
                    radius: 50,
                    child: ClipOval(
                      child: Image(
                        width: 100,
                        height: 100,
                        image: NetworkImage(
                          AppConstants.imagesBaseUrl +
                              "/profile_images/" +
                              (user?.profilePic ?? ""),
                        ),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                )
              : CircleAvatar(
                  backgroundColor: AppColors.semiPrimary,
                  radius: 50.5,
                  child: ClipOval(
                    child: Container(
                      width: 100,
                      height: 100,
                      child: CircleAvatar(
                          backgroundImage:
                              AssetImage('assets/default_profile_pic.png')),
                    ),
                  ),
                ),
        ),
      ),
    );
  }

  Widget profileDetailsWidget() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          margin: EdgeInsets.only(left: 2, top: 5),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Text(
                user?.userName ?? "",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontFamily: "Muli",
                  color: Colors.black87.withOpacity(0.7),
                  fontSize: 20,
                ),
              ),
              (user?.userType ?? "") == "real_estate_company"
                  ? ((user?.companyName ?? "").isEmpty
                      ? Container()
                      : Row(children: [
                          Container(
                            child: Icon(
                              Icons.location_city,
                              color: AppColors.primaryColor,
                              size: 12.0,
                            ),
                          ),
                          const SizedBox(width: 3),
                          Container(
                            color: Colors.transparent,
                            child: Text(
                              user?.companyName ?? "",
                              style: TextStyle(
                                color: AppColors.headingsColor.withOpacity(0.7),
                                fontFamily: "Roboto_Medium",
                                fontWeight: FontWeight.w500,
                                fontSize: 13,
                              ),
                            ),
                          )
                        ]))
                  : Container(
                      child: Text(
                        AppConstants.userTypes[user?.userType ?? ""] ?? "",
                        style: TextStyle(
                          color: AppColors.headingsColor,
                          fontFamily: "Roboto_Medium",
                          fontSize: 14,
                        ),
                      ),
                    ),
              const SizedBox(height: 2),
              (user?.userType ?? "") == "dealer"
                  ? (user?.companyName ?? "").isEmpty
                      ? Container()
                      : Row(
                          children: [
                            Container(
                              child: Icon(
                                Icons.location_city,
                                color: AppColors.primaryColor,
                                size: 12.0,
                              ),
                            ),
                            const SizedBox(width: 3),
                            Container(
                              color: Colors.transparent,
                              child: Text(
                                user?.companyName ?? "",
                                style: TextStyle(
                                  color:
                                      AppColors.headingsColor.withOpacity(0.7),
                                  fontFamily: "Roboto_Medium",
                                  fontWeight: FontWeight.w500,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        )
                  : Container(),
              const SizedBox(height: 2),
              (user?.userLocation ?? "").isEmpty
                  ? Container()
                  : Row(children: [
                      Container(
                        child: Icon(
                          Icons.location_on,
                          color: AppColors.primaryColor,
                          size: 14.0,
                        ),
                      ),
                      const SizedBox(width: 3),
                      Container(
                        color: Colors.transparent,
                        child: Text(
                          user?.userLocation ?? "",
                          style: TextStyle(
                            color: AppColors.headingsColor.withOpacity(0.7),
                            fontFamily: "Roboto_Medium",
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ]),
              const SizedBox(height: 5),
              (user?.mobileNumber ?? "").isEmpty
                  ? Container()
                  : Row(children: [
                      Container(
                        child: Icon(
                          Icons.call,
                          color: AppColors.primaryColor,
                          size: 14.0,
                        ),
                      ),
                      const SizedBox(width: 3),
                      Container(
                        color: Colors.transparent,
                        child: Text(
                          user?.mobileNumber ?? "",
                          style: TextStyle(
                            color: AppColors.headingsColor.withOpacity(0.7),
                            fontFamily: "Roboto_Medium",
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ]),
              const SizedBox(height: 5),
              Container(
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Wrap(
                    direction: Axis.horizontal,
                    alignment: WrapAlignment.start,
                    children: cities
                        .map(
                          (i) => Container(
                            margin: const EdgeInsets.only(
                                right: 5, top: 5, bottom: 5),
                            decoration: BoxDecoration(
                              color: AppColors.primaryColor.withOpacity(0.8),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                            ),
                            padding: const EdgeInsets.only(
                                left: 5, right: 5, top: 2, bottom: 3),
                            child: Text(
                              i ?? "",
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall!
                                  .copyWith(color: Colors.white, fontSize: 11),
                            ),
                          ),
                        )
                        .toList(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget profileSectionsWidget() {
    return Column(
      children: [
        Divider(
          color: AppColors.bgColor2,
          height: 1.5,
        ),
        ListTile(
          leading: new Icon(Icons.list),
          trailing: new Icon(Icons.chevron_right),
          title: new Text(
            'Property Listings (2)',
            style: TextStyle(
                fontFamily: "Roboto_Bold",
                color: AppColors.buttonTextColor,
                fontSize: 16),
          ),
          onTap: () {
            Navigator.pop(context);
          },
        ),
        Divider(
          color: AppColors.bgColor2,
          height: 1.5,
        ),
        ListTile(
          leading: new Icon(Icons.list_alt),
          trailing: new Icon(Icons.chevron_right),
          title: new Text(
            'Ads & Promotions (5)',
            style: TextStyle(
                fontFamily: "Roboto_Bold",
                color: AppColors.buttonTextColor,
                fontSize: 16),
          ),
          onTap: () {
            Navigator.pop(context);
          },
        ),
      ],
    );
  }

  Widget buildProfileDetailsSections() {
    return Column(
      children: <Widget>[
        Column(
          children: <Widget>[
            Container(
              width: MediaQuery.of(context).size.width,
              color: AppColors.white,
              padding: EdgeInsets.only(left: 10, top: 10, bottom: 10),
              child: Container(
                //color: AppColors.bgColorLight,
                margin: EdgeInsets.only(left: 1, right: 1, top: 5, bottom: 10),
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Expanded(
                      flex: 1,
                      child: GestureDetector(
                        onTap: () {
                          /*Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) =>
                                    My_Posts_Screen(user.userId)));*/
                        },
                        child: Container(
                          //alignment: Alignment.centerLeft,
                          //color: Colors.black54,
                          //padding: EdgeInsets.only(left: 5, right: 5),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                "100",
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 15,
                                ),
                              ),
                              SizedBox(height: 5),
                              Text(
                                "Comments",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: AppColors.headingsColor,
                                    fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            "2",
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 15,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            "Posts",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: AppColors.headingsColor, fontSize: 13),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: GestureDetector(
                        onTap: () {},
                        child: Container(
                          padding: EdgeInsets.only(left: 5, right: 5),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                "11",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 15,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                "Poromotions",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: AppColors.headingsColor,
                                    fontSize: 11),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
