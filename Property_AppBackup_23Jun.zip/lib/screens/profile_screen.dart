import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:property_feeds/components/custom_icon_button.dart';
import 'package:property_feeds/configs/app_routes.dart';
import 'package:property_feeds/constants/appColors.dart';
import 'package:property_feeds/constants/appConstants.dart';
import 'package:property_feeds/models/user.dart';
import 'package:property_feeds/utils/AdHelper.dart';
import 'package:property_feeds/utils/app_utils.dart';

class ProfileScreen extends StatefulWidget {
  @override
  ProfileScreenState createState() => ProfileScreenState();
}

class ProfileScreenState extends State<ProfileScreen> {
  static Random random = Random();
  BannerAd? _ad;
  List<String> cities = [];
  bool status = false;
  User? user;

  @override
  void initState() {
    BannerAd(
      adUnitId: AdHelper.bannerAdUnitId,
      size: AdSize.mediumRectangle,
      request: AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          setState(() {
            _ad = ad as BannerAd;
          });
        },
        onAdFailedToLoad: (ad, error) {
          // Releases an ad resource when it fails to load
          ad.dispose();
          print('Ad load failed (code=${error.code} message=${error.message})');
        },
      ),
    ).load();
    SchedulerBinding.instance.addPostFrameCallback((_) {
      AppUtils.getUser().then((value) {
        setState(() {
          user = value;
          cities = (user?.interestedCities ?? "").split(',');
        });
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        title: Text("Profile",
            style: TextStyle(color: AppColors.screenTitleColor, fontSize: 16)),
        elevation: 1,
        leading: user?.accountType == "guest_account"
            ? Container()
            : IconButton(
                icon: Icon(
                  Icons.settings,
                  color: AppColors.screenTitleColor,
                ),
                onPressed: () {
                  Navigator.pushNamed(context, AppRoutes.settingsScreen);
                },
              ),
        centerTitle: true,
        actions: <Widget>[
          user?.accountType == "guest_account"
              ? Container()
              : IconButton(
                  icon: Icon(
                    Icons.edit,
                    color: AppColors.screenTitleColor,
                  ),
                  onPressed: () {
                    Navigator.pushNamed(context, AppRoutes.updateProfileScreen,
                            arguments: user)
                        .then((value) {
                      if (value != null) {
                        setState(() {
                          user = value as User?;
                          cities = (user?.interestedCities ?? "").split(',');
                        });
                      }
                    });
                  },
                ),
        ],
      ),
      body: Container(
        color: Colors.white,
        child: user?.accountType == "guest_account"
            ? setProfileGuest(context)
            : setProfile(context),
      ),
    );
  }

  Widget setProfile(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        color: AppColors.white,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            profilePictureWidget(),
            profileDetailsWidget(),
            buildProfileDetailsSections(),
            profileSectionsWidget(),
          ],
        ),
      ),
    );
  }

  Widget setProfileGuest(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        color: AppColors.white,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            profilePictureWidget(),
            profileDetailsGuestWidget(),
            guestLoginButtonWidget(),
          ],
        ),
      ),
    );
  }

  Widget guestLoginButtonWidget() {
    return Container(
      margin: const EdgeInsets.only(top: 40, left: 40, right: 40, bottom: 30),
      child: CustomIconButton(
        //width: 200,
        elevation: 1,
        cornerRadius: 10,
        text: "Login/Register account",
        color: AppColors.primaryColor,
        textStyle: const TextStyle(
            fontSize: 16,
            color: AppColors.buttonTextColorWhite,
            fontFamily: "Muli"),
        icon: Icon(
          Icons.app_registration,
          size: 25,
        ),
        onPress: () async {
          Navigator.pushNamed(context, AppRoutes.landingScreen);
        },
      ),
    );
  }

  Widget profileDetailsGuestWidget() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          margin: EdgeInsets.only(left: 2, top: 5),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Text(
                "Guest User",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontFamily: "Muli",
                  color: Colors.black87.withOpacity(0.7),
                  fontSize: 20,
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Container(
                    child: Icon(
                      Icons.location_city,
                      color: AppColors.primaryColor,
                      size: 12.0,
                    ),
                  ),
                  const SizedBox(width: 3),
                  Container(
                    color: Colors.transparent,
                    child: Text(
                      user?.defaultCity ?? "",
                      style: TextStyle(
                        color: AppColors.headingsColor.withOpacity(0.7),
                        fontFamily: "Roboto_Medium",
                        fontWeight: FontWeight.w500,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 5),
            ],
          ),
        ),
      ],
    );
  }

  Widget profilePictureWidget() {
    return Container(
      margin: EdgeInsets.only(left: 10, top: 10),
      child: Container(
        child: GestureDetector(
          onTap: () {},
          child: (user?.profilePic ?? "").isNotEmpty
              ? Container(
                  child: CircleAvatar(
                    backgroundColor: AppColors.semiPrimary,
                    radius: 50.5,
                    child: ClipOval(
                      child: Image(
                        width: 100,
                        height: 100,
                        image: NetworkImage(
                          AppConstants.imagesBaseUrl +
                              "/profile_images/" +
                              (user?.profilePic ?? ""),
                        ),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                )
              : CircleAvatar(
                  backgroundColor: AppColors.semiPrimary,
                  radius: 50,
                  child: ClipOval(
                    child: Container(
                      width: 100,
                      height: 100,
                      child: CircleAvatar(
                          radius: 50,
                          backgroundImage:
                              AssetImage('assets/default_profile_pic.png')),
                    ),
                  ),
                ),
        ),
      ),
    );
  }

  Widget profileDetailsWidget() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          margin: EdgeInsets.only(left: 2, top: 5),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Text(
                user?.userName ?? "",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontFamily: "Muli",
                  color: Colors.black87.withOpacity(0.7),
                  fontSize: 20,
                ),
              ),
              (user?.userType ?? "") == "real_estate_company"
                  ? ((user?.companyName ?? "").isEmpty
                      ? Container()
                      : Row(children: [
                          Container(
                            child: Icon(
                              Icons.location_city,
                              color: AppColors.primaryColor,
                              size: 12.0,
                            ),
                          ),
                          const SizedBox(width: 3),
                          Container(
                            color: Colors.transparent,
                            child: Text(
                              user?.companyName ?? "",
                              style: TextStyle(
                                color: AppColors.headingsColor.withOpacity(0.7),
                                fontFamily: "Roboto_Medium",
                                fontWeight: FontWeight.w500,
                                fontSize: 13,
                              ),
                            ),
                          )
                        ]))
                  : Container(
                      child: Text(
                        AppConstants.userTypes[user?.userType ?? ""] ?? "",
                        style: TextStyle(
                          color: AppColors.headingsColor,
                          fontFamily: "Roboto_Medium",
                          fontSize: 14,
                        ),
                      ),
                    ),
              const SizedBox(height: 2),
              (user?.userType ?? "") == "dealer"
                  ? (user?.companyName ?? "").isEmpty
                      ? Container()
                      : Row(
                          children: [
                            Container(
                              child: Icon(
                                Icons.location_city,
                                color: AppColors.primaryColor,
                                size: 12.0,
                              ),
                            ),
                            const SizedBox(width: 3),
                            Container(
                              color: Colors.transparent,
                              child: Text(
                                user?.companyName ?? "",
                                style: TextStyle(
                                  color:
                                      AppColors.headingsColor.withOpacity(0.7),
                                  fontFamily: "Roboto_Medium",
                                  fontWeight: FontWeight.w500,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        )
                  : Container(),
              const SizedBox(height: 2),
              (user?.userLocation ?? "").isEmpty
                  ? Container()
                  : Row(children: [
                      Container(
                        child: Icon(
                          Icons.location_on,
                          color: AppColors.primaryColor,
                          size: 14.0,
                        ),
                      ),
                      const SizedBox(width: 3),
                      Container(
                        color: Colors.transparent,
                        child: Text(
                          user?.userLocation ?? "",
                          style: TextStyle(
                            color: AppColors.headingsColor.withOpacity(0.7),
                            fontFamily: "Roboto_Medium",
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ]),
              const SizedBox(height: 5),
              (user?.mobileNumber ?? "").isEmpty
                  ? Container()
                  : Row(children: [
                      Container(
                        child: Icon(
                          Icons.call,
                          color: AppColors.primaryColor,
                          size: 14.0,
                        ),
                      ),
                      const SizedBox(width: 3),
                      Container(
                        color: Colors.transparent,
                        child: Text(
                          user?.mobileNumber ?? "",
                          style: TextStyle(
                            color: AppColors.headingsColor.withOpacity(0.7),
                            fontFamily: "Roboto_Medium",
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ]),
              const SizedBox(height: 5),
              Container(
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Wrap(
                    direction: Axis.horizontal,
                    alignment: WrapAlignment.start,
                    children: cities
                        .map(
                          (i) => Container(
                            margin: const EdgeInsets.only(
                                right: 5, top: 5, bottom: 5),
                            decoration: BoxDecoration(
                              color: AppColors.primaryColor.withOpacity(0.8),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                            ),
                            padding: const EdgeInsets.only(
                                left: 5, right: 5, top: 2, bottom: 3),
                            child: Text(
                              i ?? "",
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall!
                                  .copyWith(color: Colors.white, fontSize: 11),
                            ),
                          ),
                        )
                        .toList(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget profileSectionsWidget() {
    return Column(
      children: [
        Divider(
          color: AppColors.bgColor2,
          height: 1.5,
        ),
        ListTile(
          leading: new Icon(Icons.list),
          trailing: new Icon(Icons.chevron_right),
          title: new Text(
            'Property Listings (2)',
            style: TextStyle(
                fontFamily: "Roboto_Bold",
                color: AppColors.buttonTextColor,
                fontSize: 16),
          ),
          onTap: () {
            Navigator.pop(context);
          },
        ),
        Divider(
          color: AppColors.bgColor2,
          height: 1.5,
        ),
        ListTile(
          leading: new Icon(Icons.list_alt),
          trailing: new Icon(Icons.chevron_right),
          title: new Text(
            'Ads & Promotions (5)',
            style: TextStyle(
                fontFamily: "Roboto_Bold",
                color: AppColors.buttonTextColor,
                fontSize: 16),
          ),
          onTap: () {
            Navigator.pop(context);
          },
        ),
      ],
    );
  }

  Widget buildProfileDetailsSections() {
    return Column(
      children: <Widget>[
        Column(
          children: <Widget>[
            Container(
              width: MediaQuery.of(context).size.width,
              color: AppColors.white,
              padding: EdgeInsets.only(left: 10, top: 10, bottom: 10),
              child: Container(
                //color: AppColors.bgColorLight,
                margin: EdgeInsets.only(left: 1, right: 1, top: 5, bottom: 10),
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Expanded(
                      flex: 1,
                      child: GestureDetector(
                        onTap: () {
                          /*Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) =>
                                    My_Posts_Screen(user.userId)));*/
                        },
                        child: Container(
                          //alignment: Alignment.centerLeft,
                          //color: Colors.black54,
                          //padding: EdgeInsets.only(left: 5, right: 5),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                "100",
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 15,
                                ),
                              ),
                              SizedBox(height: 5),
                              Text(
                                "Comments",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: AppColors.headingsColor,
                                    fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            "2",
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 15,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            "Posts",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: AppColors.headingsColor, fontSize: 13),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: GestureDetector(
                        onTap: () {},
                        child: Container(
                          padding: EdgeInsets.only(left: 5, right: 5),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                "11",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 15,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                "Poromotions",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: AppColors.headingsColor,
                                    fontSize: 11),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
