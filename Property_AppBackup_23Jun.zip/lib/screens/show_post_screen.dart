import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:property_feeds/blocs/post/post_bloc.dart';
import 'package:property_feeds/configs/app_routes.dart';
import 'package:property_feeds/constants/appColors.dart';
import 'package:property_feeds/constants/appConstants.dart';
import 'package:property_feeds/models/post.dart';
import 'package:property_feeds/utils/app_utils.dart';

class ShowPostScreen extends StatefulWidget {
  @override
  ShowPostScreenState createState() {
    return new ShowPostScreenState();
  }
}

class ShowPostScreenState extends State<ShowPostScreen> {
  Post? post;
  PostBloc? postBloc = PostBloc();

  @override
  void initState() {
    SchedulerBinding.instance.addPostFrameCallback((_) {
      postBloc?.viewPost(post?.postId ?? "").then((value) {});
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    post = (ModalRoute.of(context)!.settings.arguments) as Post;
    return Scaffold(
      appBar: AppBar(
        leading: const BackButton(color: AppColors.screenTitleColor),
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        title: Text("Post details",
            style: TextStyle(color: AppColors.screenTitleColor, fontSize: 16)),
        elevation: 1,
        centerTitle: true,
        actions: <Widget>[
          /*IconButton(
            icon: Icon(
              Icons.search,
              color: AppColors.screenTitleColor,
            ),
            onPressed: () {},
          ),*/
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(FocusNode());
            },
            child: Container(
                padding: EdgeInsets.only(left: 5, right: 5, top: 5, bottom: 25),
                color: AppColors.white,
                //height: MediaQuery.of(context).size.height,
                child: Column(
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Expanded(
                          flex: 1,
                          child: Container(
                            padding: EdgeInsets.only(left: 10),
                            color: Colors.transparent,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Expanded(
                                  flex: 0,
                                  child: Container(
                                    child: GestureDetector(
                                      onTap: () {},
                                      child: (post?.profilePic ?? "").isNotEmpty
                                          ? Container(
                                              child: CircleAvatar(
                                                backgroundColor:
                                                    AppColors.semiPrimary,
                                                radius: 25,
                                                child: ClipOval(
                                                  child: Image(
                                                    width: 50,
                                                    height: 50,
                                                    image: NetworkImage(
                                                      AppConstants
                                                              .imagesBaseUrl +
                                                          "/profile_images/" +
                                                          (post?.profilePic ??
                                                              ""),
                                                    ),
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                              ),
                                            )
                                          : Container(
                                              child: CircleAvatar(
                                                  radius: 25,
                                                  backgroundImage: AssetImage(
                                                      'assets/default_profile_pic.png')),
                                            ),
                                    ), //GestureDetector
                                  ), // Container
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Container(
                                        margin: EdgeInsets.only(left: 10),
                                        child: Text(
                                          post?.userName ?? "",
                                          style: Theme.of(context)
                                              .textTheme
                                              .titleMedium!
                                              .copyWith(
                                                  color: Colors.black,
                                                  fontSize: 14,
                                                  height: 1,
                                                  fontWeight: FontWeight.w500),
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(left: 10),
                                        child: Text(
                                          AppUtils.getFormattedPostDate(
                                              post?.createdOn ?? ""),
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(fontSize: 11),
                                        ),
                                      ), // Container
                                    ], // children
                                  ), // Column
                                ),
                              ], // children
                            ), // Row
                          ),
                        ), // Container
                        Expanded(
                          flex: 0,
                          child: Container(
                            child: GestureDetector(
                              onTap: () {
                                showModalBottomSheet(
                                    context: context,
                                    isScrollControlled: true,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.vertical(
                                          top: Radius.circular(18.0)),
                                    ),
                                    builder: (BuildContext context) {
                                      // return your layout
                                      return Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: <Widget>[
                                          new ListTile(
                                            leading: new Icon(Icons.share),
                                            title: new Text(
                                              'Share this post',
                                              style: TextStyle(
                                                  fontFamily: "Roboto_Bold",
                                                  color:
                                                      AppColors.buttonTextColor,
                                                  fontSize: 16),
                                            ),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          Divider(
                                              color: AppColors.subTitleColor,
                                              height: 1),
                                          new ListTile(
                                            leading:
                                                new Icon(Icons.report_problem),
                                            title: new Text(
                                              'Report problem',
                                              style: TextStyle(
                                                  fontFamily: "Roboto_Bold",
                                                  color:
                                                      AppColors.buttonTextColor,
                                                  fontSize: 16),
                                            ),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                        ],
                                      );
                                    });
                              },
                              child: Container(
                                padding: EdgeInsets.only(
                                    left: 10, right: 10, top: 10, bottom: 10),
                                child: Icon(
                                  Icons.more_vert,
                                  size: 20,
                                  color: AppColors.buttonTextColor,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ], // children
                    ), // Row
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Expanded(
                          flex: 1,
                          child: Container(
                            margin: EdgeInsets.only(left: 10, right: 10),
                            color: Colors.transparent,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    Expanded(
                                      flex: 1,
                                      child: GestureDetector(
                                        onTap: () {},
                                        child: Container(
                                          margin: EdgeInsets.only(
                                              left: 1, right: 1, top: 5),
                                          child: Text(post?.postTitle ?? "",
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .titleMedium!
                                                  .copyWith(
                                                      color: Colors.black
                                                          .withOpacity(0.7),
                                                      fontSize: 15,
                                                      fontWeight:
                                                          FontWeight.bold)),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Expanded(
                                      child: GestureDetector(
                                        onTap: () {},
                                        child: Container(
                                          padding: EdgeInsets.only(
                                              left: 1,
                                              right: 1,
                                              top: 5,
                                              bottom: 2),
                                          //margin: EdgeInsets.only(top: 1, bottom: 2),
                                          child: Text(
                                              post?.postDescription ?? "",
                                              overflow: TextOverflow.fade,
                                              //maxLines: 10,
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .titleMedium!
                                                  .copyWith(
                                                      color: Colors.black87
                                                          .withOpacity(0.7),
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.w500)),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 5),
                                Container(
                                  margin: EdgeInsets.only(bottom: 5),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Icon(
                                        Icons.location_on_sharp,
                                        size: 15,
                                        color: AppColors.buttonTextColor,
                                      ),
                                      const SizedBox(width: 2),
                                      Expanded(
                                        flex: 1,
                                        child: Text(
                                          post?.propertyLocation ?? "",
                                          //textAlign: TextAlign.end,
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodyLarge!
                                              .copyWith(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w600),
                                        ),
                                      ),
                                      Container(
                                        child: Column(
                                          //mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: [
                                            (post?.propertySize ?? "").isEmpty
                                                ? Container()
                                                : Text(
                                                    "${post?.propertySize ?? ""} ${post?.propertySizeType}",
                                                    style: Theme.of(context)
                                                        .textTheme
                                                        .bodyLarge!
                                                        .copyWith(
                                                            fontSize: 12,
                                                            color:
                                                                Colors.black45,
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600),
                                                  ),
                                            const SizedBox(height: 2),
                                            (post?.propertyPrice ?? "").isEmpty
                                                ? Container()
                                                : Text(
                                                    "Rs. ${post?.propertyPrice ?? ""} ${post?.propertyPriceType}",
                                                    style: Theme.of(context)
                                                        .textTheme
                                                        .bodyLarge!
                                                        .copyWith(
                                                            fontSize: 12,
                                                            color:
                                                                Colors.black45,
                                                            fontWeight:
                                                                FontWeight
                                                                    .w600),
                                                  ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Wrap(
                                  direction: Axis.horizontal,
                                  alignment: WrapAlignment.start,
                                  children: List.generate(
                                    ((post?.postPic ?? "").split(",") ?? [])
                                        .length,
                                    (index) {
                                      return InkWell(
                                        onTap: () {
                                          Navigator.pushNamed(context,
                                              AppRoutes.previewPictureScreen,
                                              arguments: ((post?.postPic ?? "")
                                                          .split(",") ??
                                                      [])[index] ??
                                                  "");
                                        },
                                        child: Container(
                                          //margin: const EdgeInsets.only(left: 5, right: 5, top: 5, bottom: 5),
                                          child: ((post?.postPic ?? "")
                                                          .split(",") ??
                                                      [])[index]
                                                  .isNotEmpty
                                              ? Container(
                                                  height: 70,
                                                  width: 80,
                                                  decoration: BoxDecoration(
                                                    color: Colors.white,
                                                    border: Border.all(
                                                        width: 1,
                                                        color: Colors.black26),
                                                  ),
                                                  margin: EdgeInsets.only(
                                                      top: 1,
                                                      bottom: 5,
                                                      right: 5),
                                                  child:
                                                      FadeInImage.assetNetwork(
                                                    image: AppConstants
                                                            .imagesBaseUrl +
                                                        "/post_images/" +
                                                        ((post?.postPic ?? "")
                                                                .split(",") ??
                                                            [])[index],
                                                    placeholder:
                                                        "assets/picture_placeholder.png",
                                                    placeholderErrorBuilder:
                                                        (context, error,
                                                            stackTrace) {
                                                      return Image.asset(
                                                          "assets/picture_placeholder.png",
                                                          fit: BoxFit.fill);
                                                    },
                                                    imageErrorBuilder: (context,
                                                        error, stackTrace) {
                                                      return Image.asset(
                                                          "assets/picture_placeholder.png",
                                                          fit: BoxFit.fill);
                                                    },
                                                    fit: BoxFit.cover,
                                                  ), /*Image.network(
                                                    AppConstants.imagesBaseUrl +
                                                        "/post_images/" +
                                                        ((post?.postPic ?? "")
                                                                .split(",") ??
                                                            [])[index],
                                                    //scale: 5
                                                    height: 70, width: 80,
                                                    loadingBuilder: (BuildContext
                                                            ctx,
                                                        Widget? child,
                                                        ImageChunkEvent?
                                                            loadingProgress) {
                                                      return loadingProgress
                                                                  ?.cumulativeBytesLoaded ==
                                                              loadingProgress
                                                                  ?.expectedTotalBytes
                                                          ? child!
                                                          : Container(
                                                              height: 70,
                                                              width: 80,
                                                              color:
                                                                  Colors.grey);
                                                    },
                                                    errorBuilder:
                                                        (BuildContext context,
                                                            Object? exception,
                                                            StackTrace?
                                                                stackTrace) {
                                                      return Container();
                                                    },
                                                  ),*/
                                                )
                                              : Container(),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                /*Container(
                      alignment: Alignment.centerLeft,
                      child: (post?.postPic ?? "").isNotEmpty
                          ? Container(
                          margin: EdgeInsets.only(top: 1, bottom: 5),
                          child: Image(
                            width: 90,
                            height: 50,
                            image: NetworkImage(
                              AppConstants.imagesBaseUrl +
                                  "/post_images/" +
                                  (post?.postPic ?? ""),
                              //scale: 5
                            ),
                            fit: BoxFit.fitWidth,
                          ))
                          : Container(),
                    ),*/
                                //const SizedBox(height: 5),
                                Container(
                                  margin: EdgeInsets.only(
                                      top: 4, bottom: 0, left: 0, right: 0),
                                  color: Colors.grey.withOpacity(0.5),
                                  height: 0.7,
                                ), //
                                Container(
                                  color: Colors.transparent,
                                  padding: EdgeInsets.only(
                                      top: 3, bottom: 3, left: 1, right: 1),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: <Widget>[
                                      Expanded(
                                        flex: 1,
                                        child: Container(
                                          padding: EdgeInsets.only(
                                              left: 1, right: 1),
                                          child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Flexible(
                                                  child: GestureDetector(
                                                    onTap: () {},
                                                    child: Container(
                                                      margin: EdgeInsets.only(
                                                          right: 5),
                                                      padding: EdgeInsets.only(
                                                          left: 5,
                                                          right: 10,
                                                          top: 5,
                                                          bottom: 5),
                                                      child: Row(
                                                        children: <Widget>[
                                                          Container(
                                                            margin:
                                                                EdgeInsets.all(
                                                                    1),
                                                            child: Icon(
                                                              Icons.thumb_up,
                                                              size: 20,
                                                              color: /*widget
                                                          .post.userLikeStatus
                                                      ? AppColors.primaryColor
                                                      : */
                                                                  AppColors
                                                                      .buttonTextColor,
                                                            ),
                                                          ),
                                                          Container(
                                                            margin:
                                                                EdgeInsets.only(
                                                                    left: 5),
                                                            child: Text(
                                                              "10 Interested",
                                                              style: TextStyle(
                                                                fontSize: 12,
                                                                fontFamily:
                                                                    "Roboto_Bold",
                                                                color: AppColors
                                                                    .buttonTextColor,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  flex: 0),
                                              Flexible(
                                                child: GestureDetector(
                                                  onTap: () {
                                                    /*bloc.getComments(post.postId);
                                        showModalBottomSheet(
                                            context: context,
                                            isScrollControlled: true,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.vertical(
                                                      top: Radius.circular(
                                                          18.0)),
                                            ),
                                            builder: (BuildContext context) {
                                              // return your layout
                                              return SingleChildScrollView(
                                                child: Container(
                                                  padding: EdgeInsets.only(
                                                      bottom: MediaQuery.of(
                                                              context)
                                                          .viewInsets
                                                          .bottom),
                                                  child: commentsWidget(
                                                      context,
                                                      bloc,
                                                      post),
                                                ),
                                              );
                                            });*/
                                                  },
                                                  child: Container(
                                                    margin: EdgeInsets.only(
                                                        left: 5),
                                                    padding: EdgeInsets.only(
                                                        left: 5,
                                                        right: 10,
                                                        top: 5,
                                                        bottom: 5),
                                                    child: Row(
                                                      children: <Widget>[
                                                        Container(
                                                          margin:
                                                              EdgeInsets.only(
                                                                  left: 2),
                                                          child: Icon(
                                                            Icons
                                                                .chat_bubble_outline,
                                                            size: 20,
                                                            color: AppColors
                                                                .buttonTextColor,
                                                          ),
                                                        ),
                                                        Container(
                                                          margin:
                                                              EdgeInsets.only(
                                                                  left: 5),
                                                          child: Text(
                                                            "5 Comments",
                                                            style: TextStyle(
                                                              fontSize: 12,
                                                              fontFamily:
                                                                  "Roboto_Bold",
                                                              color: AppColors
                                                                  .buttonTextColor,
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                flex: 0,
                                              ),
                                              Flexible(
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  children: <Widget>[
                                                    /*Container(
                                          margin: EdgeInsets.only(left: 10),
                                          child: Icon(
                                            Icons.remove_red_eye,
                                            size: 20,
                                            color: AppColors.buttonTextColor,
                                          ),
                                        ),*/
                                                    GestureDetector(
                                                      onTap: () {},
                                                      child: Container(
                                                        padding:
                                                            EdgeInsets.only(
                                                                left: 5,
                                                                right: 5,
                                                                top: 8,
                                                                bottom: 8),
                                                        margin: EdgeInsets.only(
                                                            left: 5, right: 0),
                                                        child: Text("20 views",
                                                            style: Theme.of(
                                                                    context)
                                                                .textTheme
                                                                .bodySmall),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                flex: 1,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                )),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }
}
