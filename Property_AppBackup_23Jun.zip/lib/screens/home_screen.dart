import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:property_feeds/screens/feeds_screen.dart';
import 'package:property_feeds/screens/news_screen.dart';
import 'package:property_feeds/screens/profile_screen.dart';
import 'package:property_feeds/screens/promotions_screen.dart';

class HomeScreen extends StatefulWidget {
  static String routeName = "/main";

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late PageController _pageController;
  int _page = 2;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: PageView(
          physics: NeverScrollableScrollPhysics(),
          controller: _pageController,
          onPageChanged: onPageChanged,
          children: <Widget>[
            NewsScreen(),
            Promotions(),
            Feeds(),
            ProfileScreen(),
            //SettingsScreen(),
          ],
        ),
        bottomNavigationBar: /*Theme(
          data: Theme.of(context).copyWith(
            // sets the background color of the `BottomNavigationBar`
            canvasColor: Theme.of(context).secondaryHeaderColor,
            // sets the active color of the `BottomNavigationBar` if `Brightness` is light
            primaryColor: AppColors.primaryColor,
            textTheme: Theme.of(context).textTheme.copyWith(
                  caption: TextStyle(color: Colors.grey[500]),
                ),
          ),
          child:*/
            BottomNavigationBar(
          //showSelectedLabels: false,
          //showUnselectedLabels: false,
          backgroundColor: Colors.white,
          type: BottomNavigationBarType.fixed,
          items: <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              label: "News",
              icon: Icon(
                Icons.chrome_reader_mode,
              ),
            ),
            BottomNavigationBarItem(
              label: "Promotions",
              icon: Icon(
                Icons.business_center,
              ),
            ),
            BottomNavigationBarItem(
              label: "Properties",
              icon: Icon(
                Icons.timeline,
              ),
            ),
            /* BottomNavigationBarItem(
                label: "Notifications",
                icon: Icon(
                  Icons.notifications,
                ),
              ),*/
            BottomNavigationBarItem(
              label: "Profile",
              icon: Icon(
                Icons.account_box,
              ),
            ),
            /* BottomNavigationBarItem(
              label: "Settings",
              icon: Icon(
                Icons.settings,
              ),
            ),*/
          ],
          onTap: navigationTapped,
          currentIndex: _page,
        ),
        //),
      ),
    );
  }

  void navigationTapped(int page) {
    _pageController.jumpToPage(page);
  }

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: 2);
    Future<InitializationStatus> _initGoogleMobileAds() {
      // TODO: Initialize Google Mobile Ads SDK
      return MobileAds.instance.initialize();
    }
  }

  @override
  void dispose() {
    super.dispose();
    _pageController.dispose();
  }

  void onPageChanged(int page) {
    setState(() {
      this._page = page;
    });
  }
}
