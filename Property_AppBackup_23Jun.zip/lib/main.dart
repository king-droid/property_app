import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:property_feeds/blocs/complete_profile/complete_profile_bloc.dart';
import 'package:property_feeds/blocs/get_posts/get_posts_bloc.dart';
import 'package:property_feeds/blocs/get_posts_views/get_post_views_bloc.dart';
import 'package:property_feeds/blocs/get_profile/get_profile_bloc.dart';
import 'package:property_feeds/blocs/login/login_bloc.dart';
import 'package:property_feeds/blocs/post/post_bloc.dart';
import 'package:property_feeds/configs/app_routes.dart';
import 'package:property_feeds/configs/theme.dart';
import 'package:property_feeds/firebase_options.dart';
import 'package:property_feeds/provider/user_provider.dart';
import 'package:provider/provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  /// Initialize Firebase
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await FirebaseAppCheck.instance.activate(
    webRecaptchaSiteKey: 'recaptcha-v3-site-key',
    // Default provider for Android is the Play Integrity provider. You can use the "AndroidProvider" enum to choose
    // your preferred provider. Choose from:
    // 1. debug provider
    // 2. safety net provider
    // 3. play integrity provider
    androidProvider: AndroidProvider.debug,
  );
  //FirebaseAuth.instance.setSettings(appVerificationDisabledForTesting: true);
  if (!kIsWeb) {
    FirebaseCrashlytics.instance.setCrashlyticsCollectionEnabled(!kDebugMode);
    FirebaseAnalytics.instance.setAnalyticsCollectionEnabled(!kDebugMode);
  }

  runApp(MultiProvider(
      providers: [ChangeNotifierProvider(create: (_) => UserProvider())],
      child: const MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider<LoginBloc>(
            create: (BuildContext context) => LoginBloc(),
          ),
          BlocProvider<CompleteProfileBloc>(
            create: (BuildContext context) => CompleteProfileBloc(),
          ),
          BlocProvider<PostBloc>(
            create: (BuildContext context) => PostBloc(),
          ),
          BlocProvider<GetPostsBloc>(
            create: (BuildContext context) => GetPostsBloc(),
          ),
          BlocProvider<GetPostViewsBloc>(
            create: (BuildContext context) => GetPostViewsBloc(),
          ),
          BlocProvider<GetProfileBloc>(
            create: (BuildContext context) => GetProfileBloc(),
          ),
        ],
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          title: "Property Feeds",
          theme: theme(),
          routes: routes,
        ));
  }
}
